/********************************************************************
 This file is a custom kwin effects extension for the KDE project.

 2022, Reverse engineered by Leaf Watoru

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*********************************************************************/
/*global effect, effects, animationTime, Effect*/
var kwinDevEffect = {
    duration: animationTime(300),
    loadConfig: function () {
        "use strict";
        kwinDevEffect.duration = animationTime(300);
    },
    windowClosed: function (window) {
        "use strict";
        kwinDevEffect.duration = animationTime(300);
        /*
        // maximize 1000% on close
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 10.0,
              value2: 10.0
          }, 
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        */
        
        /*
        // maximize 1000%
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 10.0,
              value2: 10.0
          }, 
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        */

        /*
        // minimize to center
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        */
        
        
                
        /*
        // zoom in from bottom
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 200
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */
        
        /*
        // minimize to top
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: -200
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */
        
        /*
        // minimize to left
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: -200,
              value2: 0
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */
        
        /*
        // minimize to right
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 200,
              value2: 0
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */

        
        
        /*
        // slide to right
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 200,
              value2: 0
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */
        
        /*
        // slide to left
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: -200,
              value2: 0
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */
        
        /*
        // slide to top
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: -200
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */
       
        /*
        // slide to bottom
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 200
          },
          {
              value1: 0,
              value2: 0
          }
        );
        */
        
        /*
        // jump down
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: 0
          },
          {
              value1: window.width,
              value2: window.height
          }
        );
        */
        
        
        /*
        // shrink horizontally to center
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: 0
          },
          {
              value1: window.width,
              value2: window.height
          }
        );
        */
        
        
        /*
        // fly and minimize to right
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: window.height
          },
          {
              value1: window.width,
              value2: window.height
          }
        );
        */
        
        
        /*
        // shrink vertically to center
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: window.height
          },
          {
              value1: window.width,
              value2: window.height
          }
        );
        */
        
        /*
        // shrink verticaly
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: window.height * 2
          },
          {
              value1: window.width,
              value2: window.height
          }
        );
        */

        
        // shrink horizontally
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width * 2,
              value2: 0
          },
          {
              value1: window.width,
              value2: window.height
          }
        );
        

        
        /*
        // zoom flip
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Rotation, kwinDevEffect.duration, 
          {
              value1: -90,
              value2: -90,
          },
          {
              value1: 0,
              value2: 0,
          }
        );
        */
        
        /*
        // flip
        effect.animate(window, Effect.Rotation, kwinDevEffect.duration, 
          {
              value1: -90,
              value2: -90,
          },
          {
              value1: 0,
              value2: 0,
          }
        );
        */
        
        /*
        // shrink vertically and move left (paperplane-like)
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 0.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 10.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        */
        
        
        /*
        // stretch horizontally
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 10.0,
              value2: 0.0
          },
          {
              value1: 1.0,
              value2: 1.0
          }
        );
        */
        
        /*
        effect.animate(window, Effect.Opacity, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          },
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        */
    },
    windowAdded: function (window) {
        "use strict";
        kwinDevEffect.duration = animationTime(200);
        
        
        /*
        // unmaximize 1000% on open
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 10.0,
              value2: 10.0
          }
        );
        */

        /*
        // unminimize 1000% on open
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        */
        
        
        
        /*
        // move from right
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: 200,
              value2: 0
          }
        );
        */
        
        /*
        // zoom in from bottom
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: 0,
              value2: 200
          }
        );
        */
        
        /*
        // zoom in from top
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: 0,
              value2: -200
          }
        );
        */
        
        /*
        // zoom in from left
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: -200,
              value2: 0
          }
        );
        */
        
        /*
        // zoom in from right
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: 200,
              value2: 0
          }
        );
        */

        
        
        /*
        // move in from right
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: 200,
              value2: 0
          }
        );
        */
        
        /*
        // move in from left
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: -200,
              value2: 0
          }
        );
        */
        
       /* 
        // move in from top
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: 0,
              value2: -200
          }
        );
        */
       
        /*
        // move in from bottom
        effect.animate(window, Effect.Translation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0
          },
          {
              value1: 0,
              value2: 200
          }
        );
        */
        
        /*
        // jump up
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: window.height
          },
          {
              value1: window.width,
              value2: 0
          }
        );
*/
        
        
        /*
        // vertical from center
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: window.height
          },
          {
              value1: window.width,
              value2: 0
          }
        );
        */
        
        
        /*
        // fly in from right
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: window.height
          },
          {
              value1: 0,
              value2: window.height
          }
        );
*/
        
        
        /*
        // horizontal from center
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: window.height
          },
          {
              value1: 0,
              value2: window.height
          }
        );
        */
        
        /*
        // vertical rhombus assemble
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: window.height
          },
          {
              value1: 0,
              value2: window.height * 2
          }
        );
        */

        /*
        // horizontal rhombus assemble
        effect.animate(window, Effect.Size, kwinDevEffect.duration, 
          {
              value1: window.width,
              value2: window.height
          },
          {
              value1: window.width * 2,
              value2: 0
          }
        );
        */
        
        
        
        // zoom flip
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Rotation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0,
          },
          {
              value1: -90,
              value2: -90,
          }
        );
        
        
        /*
        // flip
        effect.animate(window, Effect.Rotation, kwinDevEffect.duration, 
          {
              value1: 0,
              value2: 0,
          },
          {
              value1: -90,
              value2: -90,
          }
        );
        */
        
        /*
        // ride from left thread
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          }, 
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          },
          {
              value1: 10.0,
              value2: 0.0
          }
        );
        */
        
        /*
        // thread
        effect.animate(window, Effect.Scale, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          },
          {
              value1: 10.0,
              value2: 0.0
          }
        );
        */
        
        /*
        effect.animate(window, Effect.Opacity, kwinDevEffect.duration, 
          {
              value1: 1.0,
              value2: 1.0
          },
          {
              value1: 0.0,
              value2: 0.0
          }
        );
        */
        
        
    },

    init: function () {
        "use strict";
        effect.configChanged.connect(kwinDevEffect.loadConfig);
        effects.windowClosed.connect(kwinDevEffect.windowClosed);
        effects.windowAdded.connect(kwinDevEffect.windowAdded);
    }
};
kwinDevEffect.init();
